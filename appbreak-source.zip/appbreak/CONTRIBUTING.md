# Contributions and private activity packs

Project licensing is pending owner choice. Do not publish this snapshot as a licensed FOSS release or solicit contributions under an invented licence. Once decided, replace placeholders consistently in code/content policies and examples.

An activity pack is UTF-8 JSON, schema version 1, containing `schemaVersion` and `activities`. Use `schemas/activity-pack.schema.json` and `assets/activities.json` as examples. Packs are data only: no scripts, plugins, HTML execution or downloaded executable code. Private packs import through Settings and remain on the device. Personal notes are never automatically offered for contribution.

```bash
python3 tools/validate_packs.py path/to/pack.json
flutter test
```

Use a stable namespaced ID (`yourname.activity-name`). Translations retain semantic identity through a stable base convention such as `yourname.activity-name.hi`; language is a BCP-47 tag. Preserve IDs across wording corrections; create a new ID when meaning/category changes. Existing history preserves the original recorded category. Add a documented migration for breaking schemas; unknown versions must fail safely.

Every activity needs title, category, language, estimate, description, structured instruction/narration/thinking-or-silence/completion steps, visual/input flags, accessible alternatives, author, attribution and content licence. Supply explicit source attribution and a compatible permission/licence for contributed work; no copied copyrighted riddles or unattributed translations. Original bundled content currently uses a pending-owner licence placeholder, which is rejected by the release gate.

Review before community publication:

- Clear, short instructions; comfortable participation in 20–300 seconds, including narration time.
- Quiet rest and a seated/non-movement option; no punishment for replacement or skipping.
- No strenuous exertion, forced breath-holding, diagnostic advice or eye-rest/health guarantees.
- Audio-only pathway, complete text equivalents, honest visual/input flags.
- Quiz question first, sufficient thinking time, optional answer reveal without answer buttons.
- Respect language, reading level, culture and translation quality; do not change IDs accidentally.
- Review with a screen reader and installed offline voice; test actual spoken duration.
- No requests for sensitive disclosures; recording/sharing never earns rewards.
- Run validator, inspect attribution/licence, and obtain human content review.

Community code changes require review, tests and an application release. Content packs never execute code. Public catalogue updates are not part of this MVP.
