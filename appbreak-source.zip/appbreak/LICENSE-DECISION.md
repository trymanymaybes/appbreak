# Owner decision required

No project-wide licence is assigned by this snapshot.

Recommended: Apache-2.0 for newly written code and CC-BY-4.0 for original activity content. Alternative: GPL-3.0-or-later for code if reciprocal source distribution is desired. The owner's explicit choice is required before adding licence text/SPDX declarations and publishing a FOSS release.

Third-party SDK, template and dependency licences remain their original licences, with collected notices under third_party/licenses. Their presence does not license original project work.
