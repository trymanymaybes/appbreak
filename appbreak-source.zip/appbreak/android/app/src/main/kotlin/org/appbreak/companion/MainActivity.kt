package org.appbreak.companion

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.media.*
import android.os.*
import android.speech.tts.TextToSpeech
import android.view.accessibility.AccessibilityManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import org.json.JSONObject
import java.io.File
import java.util.UUID

class MainActivity: FlutterActivity() {
    private var tts: TextToSpeech?=null
    private var ttsReady=false
    private val screenReaderListener=AccessibilityManager.TouchExplorationStateChangeListener { enabled -> if(enabled) tts?.stop() }
    private var recorder: MediaRecorder?=null
    private var recordingName: String?=null
    private var player: MediaPlayer?=null
    private var pending: MethodChannel.Result?=null
    private var fileBytes: ByteArray?=null
    private var restorePreview: JSONObject?=null
    private var channel: MethodChannel?=null
    private var recordStarted=0L
    private var audioRequest: AudioFocusRequest?=null
    private val handler=Handler(Looper.getMainLooper())
    private val stopLimit=Runnable { finishRecording() }
    override fun configureFlutterEngine(engine: FlutterEngine) {
        super.configureFlutterEngine(engine)
        getSystemService(AccessibilityManager::class.java).addTouchExplorationStateChangeListener(screenReaderListener)
        tts=TextToSpeech(this) { status -> ttsReady=status==TextToSpeech.SUCCESS }
        channel=MethodChannel(engine.dartExecutor.binaryMessenger,"org.appbreak/device")
        channel!!.setMethodCallHandler { call,result ->
            try {
                when(call.method) {
                    "allowed" -> result.success(Reminders.allowed(Store(this).use { it.read().optJSONObject("settings") ?: JSONObject() }))
                    "now" -> result.success(mapOf("wall" to System.currentTimeMillis(),"elapsed" to SystemClock.elapsedRealtime(),"boot" to Reminders.boot(this)))
                    "load" -> result.success(Store(this).use { it.read().toString() })
                    "save" -> {
                        val d=JSONObject(call.argument<String>("json")!!)
                        val doomed=d.optString("pendingDelete"); d.remove("pendingDelete")
                        Store(this).use { it.write(d) }
                        if(doomed.matches(Regex("[a-f0-9-]{36}\\.m4a"))) File(filesDir,"recordings/$doomed").delete()
                        Reminders.schedule(this); if(d.optJSONObject("session")?.optString("phase")!="due") Reminders.clear(this)
                        result.success(null)
                    }
                    "notifications" -> { if(Build.VERSION.SDK_INT>=33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),51); result.success(getSystemService(NotificationManager::class.java).areNotificationsEnabled()) }
                    "voices" -> { check(ttsReady) { "Speech engine is still starting. Try again, or use quiet mode." }; result.success(tts!!.voices.orEmpty().filter { !it.isNetworkConnectionRequired && !it.features.orEmpty().contains("notInstalled") }.map { mapOf("name" to it.name,"language" to it.locale.toLanguageTag()) }) }
                    "installVoice" -> { startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)); result.success(null) }
                    "speak" -> {
                        check(recorder==null) { "Stop recording before narration" }
                        check(ttsReady) { "No local speech engine ready. Use text or quiet mode." }
                        check(!getSystemService(AccessibilityManager::class.java).isTouchExplorationEnabled) { "TalkBack is active. Use its reading controls to avoid competing speech." }
                        val voiceName=call.argument<String>("voice")
                        val voice=tts!!.voices.orEmpty().firstOrNull { it.name==voiceName && !it.isNetworkConnectionRequired && !it.features.orEmpty().contains("notInstalled") }
                            ?: throw IllegalStateException("Select an installed offline voice in Settings. Text and quiet mode remain available.")
                        val language=java.util.Locale.forLanguageTag(call.argument<String>("language") ?: "en-IN").language
                        check(voice.locale.language==language) { "Select an offline voice matching the activity language ($language)" }
                        check(requestFocus()) { "Audio is in use; try later" }
                        tts!!.stop(); tts!!.voice=voice
                        tts!!.setSpeechRate((call.argument<Double>("rate") ?: 1.0).toFloat().coerceIn(0.5f,1.5f))
                        val params=Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME,(call.argument<Double>("volume") ?: 0.8).toFloat().coerceIn(0f,1f)) }
                        val steps=call.argument<List<Map<String,Any>>>("steps") ?: emptyList()
                        for((i,s) in steps.withIndex()) {
                            // Completion is signalled by the actual session deadline, not narration length.
                            if(s["kind"]=="completion") continue
                            if(s["kind"]=="silence" || s["kind"]=="thinking") tts!!.playSilentUtterance(((s["seconds"] as? Number)?.toLong() ?: 5)*1000,TextToSpeech.QUEUE_ADD,"silence-$i")
                            else tts!!.speak(s["text"] as? String ?: "",TextToSpeech.QUEUE_ADD,params,"step-$i")
                        }
                        result.success(null)
                    }
                    "stopSpeech" -> { tts?.stop(); result.success(null) }
                    "cue" -> { if(call.argument<Boolean>("enabled")==true) { window.decorView.performHapticFeedback(android.view.HapticFeedbackConstants.CONFIRM); val tone=ToneGenerator(AudioManager.STREAM_NOTIFICATION,35); tone.startTone(ToneGenerator.TONE_PROP_ACK,120); handler.postDelayed({tone.release()},250) }; result.success(null) }
                    "record" -> {
                        check(recorder==null) { "Already recording" }
                        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) {
                            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),52)
                            result.error("permission","Microphone permission requested. Tap Record again after granting it.",null)
                        } else { startRecording(); result.success(recordingName) }
                    }
                    "stopRecord" -> result.success(finishRecording())
                    "play" -> {
                        val name=call.argument<String>("name")!!; require(name.matches(Regex("[a-f0-9-]{36}\\.m4a")))
                        check(recorder==null); tts?.stop(); player?.release(); check(requestFocus())
                        player=MediaPlayer().apply { setDataSource(File(filesDir,"recordings/$name").path); prepare(); setOnCompletionListener { it.release(); player=null }; start() }; result.success(null)
                    }
                    "stopAudio" -> { player?.release(); player=null; tts?.stop(); result.success(null) }
                    "shareText" -> { val text=call.argument<String>("text")!!; require(text.length<=100000); startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,text),"Share selected content")); result.success(null) }
                    "shareAudio" -> {
                        val name=call.argument<String>("name")!!; require(name.matches(Regex("[a-f0-9-]{36}\\.m4a")))
                        val token=UUID.randomUUID().toString(); val directory=File(cacheDir,"shares").apply { mkdirs() }
                        directory.listFiles()?.filter { System.currentTimeMillis()-it.lastModified()>86400000 }?.forEach { it.deleteRecursively() }
                        val dest=File(directory,"$token/voice-note.m4a"); dest.parentFile!!.mkdirs(); File(filesDir,"recordings/$name").copyTo(dest)
                        val uri=android.net.Uri.parse("content://$packageName.share/$token/voice-note.m4a")
                        val send=Intent(Intent.ACTION_SEND).setType("audio/mp4").putExtra(Intent.EXTRA_STREAM,uri).putExtra(Intent.EXTRA_TEXT,call.argument<String>("text") ?: "")
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION).apply { clipData=ClipData.newRawUri("Selected voice note",uri) }
                        startActivity(Intent.createChooser(send,"Share selected recording")); result.success(null)
                    }
                    "saveText" -> { fileBytes=call.argument<String>("text")!!.toByteArray(); beginFile(result,Intent(Intent.ACTION_CREATE_DOCUMENT).setType("text/plain").putExtra(Intent.EXTRA_TITLE,"idea.txt"),60) }
                    "saveAudio" -> { val name=call.argument<String>("name")!!; require(name.matches(Regex("[a-f0-9-]{36}\\.m4a"))); fileBytes=File(filesDir,"recordings/$name").readBytes(); beginFile(result,Intent(Intent.ACTION_CREATE_DOCUMENT).setType("audio/mp4").putExtra(Intent.EXTRA_TITLE,"voice-note.m4a"),60) }
                    "backup" -> { check(recorder==null); fileBytes=Backups.make(this,call.argument<Boolean>("audio")==true); beginFile(result,Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/json").putExtra(Intent.EXTRA_TITLE,"appbreak-backup.json"),60) }
                    "importPack" -> { beginFile(result,Intent(Intent.ACTION_OPEN_DOCUMENT).setType("application/json"),62) }
                    "previewRestore" -> { check(recorder==null); beginFile(result,Intent(Intent.ACTION_OPEN_DOCUMENT).setType("application/json"),61) }
                    "restore" -> { check(recorder==null); val p=restorePreview ?: error("Choose a backup first"); Backups.restore(this,p); restorePreview=null; result.success(null) }
                    "usage" -> result.success(filesDir.walkTopDown().filter { it.isFile }.sumOf { it.length() } + getDatabasePath("companion.db").length())
                    "deleteAll" -> { finishRecording(); tts?.stop(); player?.release(); player=null; Store(this).use { it.write(JSONObject().put("schemaVersion",1),true) }; File(filesDir,"recordings").deleteRecursively(); File(cacheDir,"shares").deleteRecursively(); Reminders.clear(this); Reminders.schedule(this); result.success(null) }
                    else -> result.notImplemented()
                }
            } catch(e:Exception) { result.error("device",e.message ?: "Operation failed",null) }
        }
    }
    private fun requestFocus(): Boolean {
        val manager=getSystemService(AudioManager::class.java)
        audioRequest?.let { manager.abandonAudioFocusRequest(it) }
        val req=AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setOnAudioFocusChangeListener { if(it<0) { tts?.stop(); player?.pause(); finishRecording() } }.build()
        audioRequest=req; return manager.requestAudioFocus(req)==AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }
    private fun startRecording() {
        val dir=File(filesDir,"recordings").apply { mkdirs() }
        check(dir.usableSpace>10*1024*1024 && dir.walk().filter { it.isFile }.sumOf { it.length() }<100*1024*1024) { "Not enough recording storage (100 MiB limit)" }
        tts?.stop(); player?.release(); player=null; check(requestFocus()) { "Audio is in use" }
        val name=UUID.randomUUID().toString()+".m4a"; val file=File(dir,name)
        @Suppress("DEPRECATION") val r=MediaRecorder()
        try {
            r.setAudioSource(MediaRecorder.AudioSource.MIC); r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC); r.setAudioEncodingBitRate(64000); r.setAudioSamplingRate(22050)
            r.setOutputFile(file.path); r.setMaxDuration(300000); r.setMaxFileSize(5*1024*1024L)
            r.setOnErrorListener { _,_,_ -> finishRecording() }; r.setOnInfoListener { _,what,_ -> if(what==MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED || what==MediaRecorder.MEDIA_RECORDER_INFO_MAX_FILESIZE_REACHED) finishRecording() }
            r.prepare(); r.start(); recorder=r; recordingName=name; recordStarted=SystemClock.elapsedRealtime()
            handler.postDelayed(stopLimit,300000); window.decorView.announceForAccessibility("Recording started. Five minute limit.")
        } catch(e:Exception) { r.release(); file.delete(); throw e }
    }
    private fun finishRecording(): String? {
        val r=recorder ?: return null; recorder=null; handler.removeCallbacks(stopLimit)
        val name=recordingName; recordingName=null; var good=true
        try { r.stop() } catch(_:Exception) { good=false } finally { r.release() }
        if(!good || SystemClock.elapsedRealtime()-recordStarted<400) { File(filesDir,"recordings/$name").delete(); channel?.invokeMethod("recordEnded",mapOf("error" to "Recording was too short or interrupted")); return null }
        // Persist immediately, including when lifecycle or audio interruption stops it.
        try { Store(this).use { store -> val d=store.read(); val notes=d.optJSONArray("ideas") ?: org.json.JSONArray(); notes.put(JSONObject().put("id",UUID.randomUUID().toString()).put("title","Voice idea").put("text","").put("recording",name).put("activity",d.optJSONObject("session")?.opt("activity"))); d.put("ideas",notes); store.write(d) } } catch(e:Exception) { channel?.invokeMethod("recordEnded",mapOf("error" to "Recording file retained, but note could not be saved: ${e.message}")); return null }
        channel?.invokeMethod("recordEnded",mapOf("name" to name)); window.decorView.announceForAccessibility("Recording stopped and saved")
        return name
    }
    private fun beginFile(result:MethodChannel.Result,intent:Intent,request:Int) {
        check(pending==null) { "A file picker is already open" }; pending=result
        try { startActivityForResult(intent.addCategory(Intent.CATEGORY_OPENABLE),request) } catch(e:Exception) { pending=null; fileBytes=null; throw e }
    }
    @Deprecated("Android activity result bridge")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode !in listOf(60,61,62)) return
        val result=pending ?: return; pending=null
        try {
            val uri=data?.data
            if(resultCode!=Activity.RESULT_OK || uri==null) { result.success(null); return }
            if(requestCode==60) { contentResolver.openOutputStream(uri,"wt")!!.use { it.write(fileBytes ?: error("No export")) }; result.success("Saved to selected provider: ${uri.authority}. This may be cloud-backed.") }
            else { val bytes=contentResolver.openInputStream(uri)!!.use { input -> val out=java.io.ByteArrayOutputStream(); val buffer=ByteArray(8192); while(out.size()<=Backups.MAX) { val count=input.read(buffer); if(count<0) break; out.write(buffer,0,count) }; out.toByteArray() }; if(requestCode==62) { require(bytes.size<=1024*1024); result.success(ActivityPacks.validate(JSONObject(String(bytes,Charsets.UTF_8))).toString()); return }; val p=Backups.validate(bytes); restorePreview=p; val d=p.getJSONObject("data"); result.success(mapOf("ideas" to (d.optJSONArray("ideas")?.length() ?: 0),"sessions" to (d.optJSONArray("history")?.length() ?: 0),"provider" to uri.authority)) }
        } catch(e:Exception) { restorePreview=null; result.error("file",e.message,null) } finally { fileBytes=null }
    }
    override fun onResume() { super.onResume(); Reminders.visible=true; Reminders.clear(this) }
    override fun onPause() { Reminders.visible=false; finishRecording(); tts?.stop(); player?.pause(); super.onPause() }
    override fun onDestroy() { getSystemService(AccessibilityManager::class.java).removeTouchExplorationStateChangeListener(screenReaderListener); finishRecording(); tts?.shutdown(); player?.release(); audioRequest?.let { getSystemService(AudioManager::class.java).abandonAudioFocusRequest(it) }; super.onDestroy() }
}
