package org.appbreak.companion

import android.content.Context
import org.json.JSONObject
import org.json.JSONArray
import java.security.MessageDigest
import java.io.File
import android.util.Base64

object Backups {
    const val MAX = 24 * 1024 * 1024
    private fun hash(s: String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    fun make(c:Context, includeAudio:Boolean): ByteArray {
        val data=Store(c).use { it.read() }
        data.remove("session"); data.remove("pendingDelete"); data.remove("revision")
        val audio=JSONObject(); val notes=data.optJSONArray("ideas") ?: JSONArray()
        for(i in 0 until notes.length()) {
            val note=notes.getJSONObject(i); val name=note.optString("recording")
            if(includeAudio && name.matches(Regex("[a-f0-9-]{36}\\.m4a"))) {
                val file=File(c.filesDir,"recordings/$name")
                if(file.exists()) audio.put(name,Base64.encodeToString(file.readBytes(),Base64.NO_WRAP)) else note.put("recording",JSONObject.NULL)
            } else note.put("recording",JSONObject.NULL)
        }
        val payload=JSONObject().put("data",data).put("audio",audio).toString()
        val bytes=JSONObject().put("format","appbreak-backup").put("version",1).put("payload",payload).put("sha256",hash(payload)).toString().toByteArray()
        require(bytes.size<=MAX) { "Backup exceeds 24 MiB; exclude recordings" }
        return bytes
    }
    fun validate(bytes: ByteArray): JSONObject {
        require(bytes.size<=MAX) { "Backup too large" }
        val envelope=JSONObject(String(bytes,Charsets.UTF_8))
        require(envelope.getString("format")=="appbreak-backup" && envelope.getInt("version")==1)
        val raw=envelope.getString("payload"); require(hash(raw)==envelope.getString("sha256")) { "Integrity check failed" }
        val p=JSONObject(raw); val d=p.getJSONObject("data"); require(d.getInt("schemaVersion")==1)
        for(key in listOf("ideas","history")) {
            val list=d.optJSONArray(key) ?: JSONArray(); require(list.length()<=10000)
            val seen=mutableSetOf<String>()
            for(i in 0 until list.length()) {
                val item=list.getJSONObject(i); val id=item.getString("id"); require(id.length in 1..100 && seen.add(id)) { "Duplicate or invalid IDs" }
                if(key=="ideas") { require(item.getString("text").length<=100000); require(item.optString("title").length<=200) }
                else { require(item.getString("date").matches(Regex("\\d{4}-\\d{2}-\\d{2}"))); require(item.getString("category") in listOf("quiet","movement","breathing","hydration","quiz","imagination")) }
            }
        }
        val s=d.optJSONObject("settings") ?: JSONObject()
        require(s.optInt("workSeconds",1500) in 60..14400 && s.optInt("breakSeconds",60) in 20..300)
        for(key in listOf("activeStart","activeEnd","quietStart","quietEnd")) if(s.has(key)) require(s.getInt(key) in 0..23)
        for(key in listOf("quiet","cues","gamification","activeEnabled","quietHours")) if(s.has(key)) s.getBoolean(key)
        if(s.has("rate")) require(s.getDouble("rate") in 0.5..1.5)
        if(s.has("volume")) require(s.getDouble("volume") in 0.0..1.0)
        if(s.has("goal")) require(s.getInt("goal") in 1..30)
        if(s.has("categories")) { val cats=s.getJSONArray("categories"); for(i in 0 until cats.length()) require(cats.getString(i) in listOf("quiet","movement","breathing","hydration","quiz","imagination")) }
        if(d.has("customActivities") && d.getJSONArray("customActivities").length()>0) ActivityPacks.validate(JSONObject().put("schemaVersion",1).put("activities",d.getJSONArray("customActivities")))
        val a=p.getJSONObject("audio"); var total=0
        a.keys().forEach { name ->
            require(name.matches(Regex("[a-f0-9-]{36}\\.m4a"))) { "Invalid recording path" }
            val decoded=Base64.decode(a.getString(name),Base64.NO_WRAP); total+=decoded.size
            require(decoded.size<=5*1024*1024 && total<=16*1024*1024)
            require(decoded.size>=12 && String(decoded.copyOfRange(4,8),Charsets.US_ASCII)=="ftyp") { "Not MPEG-4 audio" }
        }
        val notes=d.optJSONArray("ideas") ?: JSONArray()
        for(i in 0 until notes.length()) {
            val note=notes.getJSONObject(i)
            if(!note.isNull("recording")) require(a.has(note.getString("recording"))) { "Missing audio" }
        }
        return p
    }
    fun restore(c:Context,p:JSONObject) {
        // New random file identities avoid overwriting files referenced by old data.
        val dir=File(c.filesDir,"recordings").apply { mkdirs() }
        val staged=mutableListOf<File>(); val mapping=mutableMapOf<String,String>()
        try {
            val a=p.getJSONObject("audio")
            a.keys().forEach { old ->
                val name=java.util.UUID.randomUUID().toString()+".m4a"
                val f=File(dir,name); staged.add(f); f.outputStream().use { it.write(Base64.decode(a.getString(old),Base64.NO_WRAP)); it.fd.sync() }; mapping[old]=name
            }
            val d=p.getJSONObject("data"); d.remove("session"); d.remove("pendingDelete")
            val notes=d.optJSONArray("ideas") ?: JSONArray()
            for(i in 0 until notes.length()) { val n=notes.getJSONObject(i); if(!n.isNull("recording")) n.put("recording",mapping[n.getString("recording")]) }
            Store(c).use { it.write(d,true) }
        } catch(e:Exception) { staged.forEach { it.delete() }; throw e }
        Reminders.clear(c); Reminders.schedule(c)
        // Orphan cleanup only after successful transaction.
        val keep=mapping.values.toSet(); dir.listFiles()?.filter { it.name !in keep }?.forEach { it.delete() }
    }
}
