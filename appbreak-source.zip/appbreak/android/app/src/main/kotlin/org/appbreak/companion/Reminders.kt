// SPDX-License-Identifier: Apache-2.0
package org.appbreak.companion

import android.app.*
import android.content.*
import android.os.*
import android.provider.Settings
import org.json.JSONObject
import java.util.Calendar

object Reminders {
    var visible = false
    fun boot(c: Context): Int = Settings.Global.getInt(c.contentResolver,Settings.Global.BOOT_COUNT,0)
    fun remaining(c: Context,s: JSONObject): Long = if(s.optString("timing")=="screen" && s.optString("phase")=="work") s.optLong("activeRemaining") else if(s.optInt("boot",-1)==boot(c)) s.optLong("elapsedDue")-SystemClock.elapsedRealtime() else s.optLong("wallDue")-System.currentTimeMillis()
    private fun alarm(c: Context) = PendingIntent.getBroadcast(c, 1, Intent(c,ReminderReceiver::class.java).setAction("alarm"), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    fun schedule(c: Context) {
        val manager = c.getSystemService(AlarmManager::class.java)
        manager.cancel(alarm(c))
        val s = Store(c).use { it.read().optJSONObject("session") } ?: return
        if(s.optString("phase") !in listOf("work","rest","paused")) return
        manager.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime()+(if(s.optString("timing")=="screen" && s.optString("phase")=="work") 60000L else remaining(c,s)).coerceAtLeast(1000),alarm(c))
    }
    fun allowed(settings: JSONObject): Boolean {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        fun within(start: Int,end: Int): Boolean = if(start==end) true else if(start<end) hour>=start && hour<end else hour>=start || hour<end
        if(settings.optBoolean("activeEnabled") && !within(settings.optInt("activeStart",9),settings.optInt("activeEnd",18))) return false
        if(settings.optBoolean("quietHours") && within(settings.optInt("quietStart",22),settings.optInt("quietEnd",7))) return false
        return true
    }
    fun clear(c: Context) { c.getSystemService(NotificationManager::class.java).cancel(1) }
    fun notify(c: Context, finished: Boolean) {
        if(visible) return
        val manager=c.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel("breaks_v2","Break reminders",NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(c,10,Intent(c,MainActivity::class.java).setAction("openBreak"),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val b=Notification.Builder(c,"breaks_v2").setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(if(finished) "Your break time has ended" else "Time for a gentle break")
            .setContentText(if(finished) "Return when ready. Participation is yours to confirm." else "Start, postpone, or pause. No activity is required.")
            .setContentIntent(open).setAutoCancel(true)
            .addAction(Notification.Action.Builder(null,if(finished) "Open" else "Start break",open).build())
        if(!finished) for((index,label,action) in listOf(Triple(11,"Postpone 5 min","postpone"),Triple(12,"Pause 15 min","pause"))) {
            val pi=PendingIntent.getBroadcast(c,index,Intent(c,ReminderReceiver::class.java).setAction(action),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            b.addAction(Notification.Action.Builder(null,label,pi).build())
        }
        try { manager.notify(1,b.build()) } catch(_: SecurityException) { /* Setup screen reports disabled alerts. */ }
        val settings=Store(c).use { it.read().optJSONObject("settings") }
        if(!finished && settings?.optBoolean("popup")==true && Settings.canDrawOverlays(c) && c.getSystemService(PowerManager::class.java).isInteractive && !c.getSystemService(KeyguardManager::class.java).isKeyguardLocked) {
            // User-granted background-activity exemption. Notification remains until visible.
            try { c.startActivity(Intent(c,BreakPopupActivity::class.java).putExtra("breakPopup",true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)) } catch(_:Exception) { }
        }
    }
}
class ReminderReceiver: BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        if(intent.action=="testReminder") {
            Store(c).use { store -> val d=store.read(); if(d.optJSONObject("session")?.optString("phase") in listOf(null,"idle")) {
                d.put("session",JSONObject().put("id",java.util.UUID.randomUUID().toString()).put("phase","due").put("wallDue",0).put("elapsedDue",0).put("boot",Reminders.boot(c)).put("remainingMs",0).put("resumePhase","work"));store.write(d)
            } }; Reminders.notify(c,false);return
        }
        ScreenTime.refresh(c)
        Store(c).use { store ->
            val d=store.read(); val s=d.optJSONObject("session") ?: return
            val phase=s.optString("phase"); val savedRemaining=Reminders.remaining(c,s).coerceAtLeast(0); val now=System.currentTimeMillis(); val mono=SystemClock.elapsedRealtime()
            fun deadline(duration: Long) { s.put("wallDue",now+duration).put("elapsedDue",mono+duration).put("boot",Reminders.boot(c)) }
            when(intent.action) {
                "postpone" -> { if(phase !in listOf("work","due")) return; s.put("phase","work").put("activeRemaining",300000); ScreenTime.initialize(c,s); deadline(300000); Reminders.clear(c) }
                "pause" -> { if(phase !in listOf("work","due")) return; s.put("phase","paused").put("resumePhase","work").put("remainingMs",savedRemaining); deadline(900000); Reminders.clear(c) }
                else -> {
                    if(phase !in listOf("work","rest","paused")) return
                    if(Reminders.remaining(c,s)< -43200000L) { d.remove("session"); store.write(d); Reminders.schedule(c); return }
                    if(Reminders.remaining(c,s)>0) { Reminders.schedule(c); return }
                    if(phase=="paused") { s.put("phase",s.optString("resumePhase","work")); deadline(s.optLong("remainingMs")); s.put("activeRemaining",s.optLong("remainingMs")); ScreenTime.initialize(c,s) }
                    else {
                        val permitted=Reminders.allowed(d.optJSONObject("settings") ?: JSONObject())
                        s.put("phase",if(phase=="rest") "finished" else if(permitted) "due" else "idle")
                        store.write(d) // Persist before posting: repeat delivery cannot notify twice.
                        if(permitted) Reminders.notify(c,phase=="rest")
                        Reminders.schedule(c); return
                    }
                }
            }
            store.write(d)
        }
        Reminders.schedule(c)
    }
}
