package org.appbreak.companion
import org.json.JSONObject
object ActivityPacks {
    fun validate(pack:JSONObject):JSONObject {
        require(pack.getInt("schemaVersion")==1)
        val list=pack.getJSONArray("activities"); require(list.length() in 1..200)
        val ids=mutableSetOf<String>()
        for(i in 0 until list.length()) {
            val a=list.getJSONObject(i); require(a.getInt("schemaVersion")==1)
            require(a.getString("id").matches(Regex("[a-z0-9._-]{1,80}")) && ids.add(a.getString("id")))
            require(a.getString("category") in listOf("quiet","movement","breathing","hydration","quiz","imagination"))
            require(a.getInt("estimatedSeconds") in 20..300)
            for(key in listOf("title","language","description","author","attribution","contentLicense")) require(a.getString(key).length in 1..2000)
            a.getBoolean("requiresVisualAttention"); a.getBoolean("requiresInput")
            val alternatives=a.getJSONArray("accessibleAlternatives"); require(alternatives.length() in 1..20)
            for(j in 0 until alternatives.length()) require(alternatives.getString(j).length in 1..2000)
            val steps=a.getJSONArray("steps"); require(steps.length() in 1..30)
            var silence=0
            for(j in 0 until steps.length()) {
                val step=steps.getJSONObject(j)
                require(step.getString("kind") in listOf("instruction","narration","silence","thinking","completion"))
                if(step.getString("kind") in listOf("silence","thinking")) { val time=step.getInt("seconds");require(time in 1..300);silence+=time }
                else require(step.getString("text").length in 1..2000)
            }
            require(silence<=a.getInt("estimatedSeconds"))
            for(key in listOf("answer","reflectionQuestion")) if(a.has(key)) require(a.getString(key).length<=2000)
        }
        return pack
    }
}
