// SPDX-License-Identifier: Apache-2.0
package org.appbreak.companion
import org.junit.Assert.*
import org.junit.Test
class ScreenIntervalsTest {
 @Test fun lockedAndScreenOffDoNotCount() {
  val r=ScreenIntervals.count(0,5000,true,true,listOf(1000L to 16,3000L to 15,3000L to 17,4000L to 18))
  assertEquals(2000L,r.used)
 }
 @Test fun duplicateBoundaryEventsDoNotDoubleCount() {
  val r=ScreenIntervals.count(1000,3000,false,true,listOf(1000L to 15,1000L to 15,2000L to 16))
  assertEquals(1000L,r.used)
 }
 @Test fun unrelatedAndOutOfRangeEventsIgnored() {
  assertEquals(1000L,ScreenIntervals.count(1000,2000,true,true,listOf(0L to 16,1500L to 1,3000L to 16)).used)
 }
 @Test fun lockedVideoDoesNotCountButUnlockedVideoDoes() {
  assertEquals(0L,ScreenIntervals.count(0,1000,true,false,emptyList()).used)
  assertEquals(1000L,ScreenIntervals.count(0,1000,true,true,emptyList()).used)
 }
}
