// ignore_for_file: deprecated_member_use
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/semantics.dart';
import '../application/controller.dart';
import '../domain/session.dart';
import '../domain/activity.dart';
import '../domain/progress.dart';
import '../platform/device.dart';

class Home extends StatefulWidget {
  final Companion controller;
  const Home({super.key, required this.controller});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> with WidgetsBindingObserver {
  Companion get c => widget.controller;
  int tab = 0;
  String search = '';
  bool recording = false, includeAudio = false;
  String? categoryFilter;
  List<Map<String, dynamic>> voices = [];
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    c.addListener(changed);
    c.init();
    Device.channel.setMethodCallHandler((call) async {
      if (call.method == 'recordEnded') {
        final args = Map<String, dynamic>.from(call.arguments as Map);
        if (args['error'] != null && mounted) message(args['error']);
        recording = false;
        await c.refresh();
        if (mounted) setState(() {});
      }
    });
  }

  void changed() {
    if (mounted) setState(() {});
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    c.visible = state == AppLifecycleState.resumed;
    if (c.visible) c.refresh();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    c.removeListener(changed);
    c.dispose();
    Device.channel.setMethodCallHandler(null);
    super.dispose();
  }

  Future<void> run(Future<dynamic> Function() fn) async {
    try {
      final result = await fn();
      if (result is String && mounted) message(result);
    } catch (e) {
      if (mounted) message('$e');
    }
  }

  void message(String s) => ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(s), duration: const Duration(seconds: 7)),
  );
  Future<bool> confirm(String title, String detail) async =>
      await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(title),
          content: Text(detail),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Confirm'),
            ),
          ],
        ),
      ) ??
      false;
  Widget button(String label, VoidCallback action, {bool enabled = true}) =>
      Padding(
        padding: const EdgeInsets.only(right: 8, bottom: 8),
        child: ElevatedButton(
          onPressed: enabled ? action : null,
          child: Text(label),
        ),
      );
  Widget section(String title, List<Widget> children) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 12),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(title, style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 12),
        ...children,
      ],
    ),
  );
  @override
  Widget build(BuildContext context) {
    final pages = [dashboard, ideas, achievements, settings];
    return Scaffold(
      appBar: AppBar(
        title: const Text('AppBreak'),
        actions: [
          IconButton(
            tooltip: 'Stop all audio',
            icon: const Icon(Icons.volume_off_outlined),
            onPressed: () => run(() => c.device.call('stopAudio')),
          ),
        ],
      ),
      body: SafeArea(
        child: Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 760),
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                if (c.error != null)
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Text(c.error!),
                    ),
                  ),
                if (recording)
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(16),
                      child: Text(
                        '● Recording microphone — stops after 5 minutes, on lock, or when you leave this app.',
                      ),
                    ),
                  ),
                ...pages[tab](),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.spa_outlined), label: 'Today'),
          NavigationDestination(icon: Icon(Icons.edit_note), label: 'Ideas'),
          NavigationDestination(
            icon: Icon(Icons.emoji_events_outlined),
            label: 'Progress',
          ),
          NavigationDestination(
            icon: Icon(Icons.settings_outlined),
            label: 'Settings',
          ),
        ],
      ),
    );
  }

  List<Widget> dashboard() {
    final s = c.session;
    final rest = [Phase.rest, Phase.finished].contains(s.phase);
    final activity = c.current;
    final seconds = (s.remaining(c.moment) / 1000).ceil();
    final today = DateTime.now().toIso8601String().substring(0, 10);
    final completed = c.history.where((h) => h['date'] == today).length;
    return [
      Text(
        'A little space in your day.',
        style: Theme.of(context).textTheme.headlineMedium,
      ),
      const SizedBox(height: 16),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                {
                  Phase.idle: 'Ready when you are',
                  Phase.work: 'Work session',
                  Phase.due: 'Break available',
                  Phase.rest: 'Your break',
                  Phase.paused: 'Paused temporarily',
                  Phase.finished: 'Break time ended',
                }[s.phase]!,
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              if ([Phase.work, Phase.rest, Phase.paused].contains(s.phase)) ...[
                const SizedBox(height: 12),
                ExcludeSemantics(
                  child: Text(
                    '${seconds ~/ 60}:${(seconds % 60).toString().padLeft(2, '0')}',
                    style: Theme.of(context).textTheme.displaySmall,
                  ),
                ),
                Text(
                  s.phase == Phase.paused
                      ? 'Automatically resumes in about ${(seconds / 60).ceil()} minutes.'
                      : 'Due around ${TimeOfDay.fromDateTime(DateTime.fromMillisecondsSinceEpoch(c.moment.wall + s.remaining(c.moment))).format(context)}',
                ),
                TextButton(
                  onPressed: () => SemanticsService.announce(
                    '$seconds seconds remaining',
                    Directionality.of(context),
                  ),
                  child: const Text('Read remaining time'),
                ),
              ],
              const Text(
                'This measures a session you started, not active screen use.',
              ),
              const SizedBox(height: 16),
              Wrap(
                children: [
                  if (s.phase == Phase.idle)
                    button('Start work session', () => c.start()),
                  if (!rest) button('Take a break now', () => c.breakNow()),
                  if ([Phase.work, Phase.rest, Phase.due].contains(s.phase))
                    button('Pause for 15 min', () => c.pause()),
                  if (s.phase == Phase.paused)
                    button('Resume', () => c.resume()),
                  if ([
                    Phase.work,
                    Phase.due,
                    Phase.rest,
                    Phase.finished,
                  ].contains(s.phase))
                    button('Postpone 5 min', () => c.postpone()),
                  if (s.phase != Phase.idle)
                    button('Cancel session', () => c.cancel()),
                ],
              ),
            ],
          ),
        ),
      ),
      if (rest && activity != null)
        section(activity.title, [
          Text(
            '${activity.data['requiresVisualAttention'] == true ? 'Visual recreation' : 'Eyes-away'} • ${activity.category} • ${activity.data['requiresInput'] == true ? 'optional input' : 'no input required'}',
          ),
          const SizedBox(height: 12),
          Text(activity.text, style: Theme.of(context).textTheme.bodyLarge),
          const SizedBox(height: 16),
          Wrap(
            children: [
              button('Play / replay instructions', () => run(c.narrate)),
              button(
                'Stop narration',
                () => run(() => c.device.call('stopSpeech')),
              ),
              button(
                'Choose quiet rest',
                () => run(
                  () => c.act(() async {
                    final quiet = c.activities.firstWhere(
                      (a) => a.id == 'quiet.soft',
                    );
                    c.session = Session(id: s.id).at(
                      Phase.rest,
                      s.remaining(c.moment),
                      c.moment,
                      activityId: quiet.id,
                    );
                    await c.device.call('stopSpeech');
                  }),
                ),
              ),
              button('Capture an idea', () => editIdea()),
              if (activity.data['answer'] != null)
                button(
                  'Reveal answer',
                  () => showDialog(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      title: const Text('Answer'),
                      content: Text(activity.data['answer']),
                      actions: [
                        TextButton(
                          onPressed: () => run(
                            () => c.device.call('speak', {
                              'steps': [
                                {
                                  'kind': 'narration',
                                  'text': activity.data['answer'],
                                },
                              ],
                              'voice': c.settings['voice'],
                              'rate': c.settings['rate'] ?? 1.0,
                              'volume': c.settings['volume'] ?? 0.8,
                            }),
                          ),
                          child: const Text('Read answer'),
                        ),
                        TextButton(
                          onPressed: () => Navigator.pop(ctx),
                          child: const Text('Close'),
                        ),
                      ],
                    ),
                  ),
                ),
              button(
                s.phase == Phase.finished
                    ? 'Confirm participation'
                    : 'I participated — finish early',
                () => c.complete(),
              ),
              button('Skip without credit', () => c.cancel()),
            ],
          ),
          const Text(
            'Progress records your participation, not verified movement, hydration, or eye rest. You may leave or skip at any time.',
          ),
        ]),
      section('Today', [
        Text('$completed completed breaks'),
        const Text(
          'Quiet rest counts too. No streak is lost when you take a day off.',
        ),
        if (c.settings['gamification'] != false)
          Text(
            'Your daily goal: ${c.settings['goal'] ?? 3} breaks. Progress: $completed.',
          ),
      ]),
      const Text(
        'Background reminders can be delayed by Android, battery settings or notification permissions. No overdue backlog is replayed.',
      ),
    ];
  }

  Future<void> editIdea([Map<String, dynamic>? idea]) async {
    final text = TextEditingController(text: idea?['text'] ?? '');
    final title = TextEditingController(text: idea?['title'] ?? 'Idea');
    final saved = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(idea == null ? 'Capture an idea' : 'Edit idea'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: title,
                maxLength: 200,
                decoration: const InputDecoration(labelText: 'Title'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: text,
                maxLines: 5,
                maxLength: 100000,
                decoration: const InputDecoration(
                  labelText: 'Your private note',
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Save locally'),
          ),
        ],
      ),
    );
    if (saved == true)
      await c.saveIdea(
        text.text,
        id: idea?['id'],
        recording: idea?['recording'],
        title: title.text,
      );
    // Dialog transition may still reference its controllers; let Flutter collect them.
  }

  Future<void> sharePreview(String content, {String? audio}) async {
    final text = TextEditingController(text: content);
    final approved = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Preview exactly what leaves'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: text,
                maxLines: 6,
                decoration: const InputDecoration(
                  labelText: 'Selected text only — edit freely',
                ),
              ),
              const SizedBox(height: 12),
              Text(
                audio == null
                    ? 'Only this text leaves. No recording, timestamps, filenames or unrelated history is attached. The receiving app controls it after sharing.'
                    : 'You explicitly selected ONE recording. The attachment will be named voice-note.m4a. Listen to it before sharing; its spoken content may be private. No other notes are included.',
              ),
              if (audio != null)
                TextButton(
                  onPressed: () =>
                      run(() => c.device.call('play', {'name': audio})),
                  child: const Text('Preview selected recording'),
                ),
              const Text('Opening the share sheet does not prove publication.'),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Open share sheet'),
          ),
        ],
      ),
    );
    if (approved == true)
      await run(
        () => c.device.call(audio == null ? 'shareText' : 'shareAudio', {
          'text': text.text,
          if (audio != null) 'name': audio,
        }),
      );
  }

  List<Widget> ideas() => [
    Text(
      'Ideas, kept here.',
      style: Theme.of(context).textTheme.headlineMedium,
    ),
    const SizedBox(height: 16),
    Wrap(
      children: [
        button('Write an idea', () => editIdea()),
        button(
          recording ? 'Stop and save recording' : 'Record a voice idea',
          () => run(() async {
            await c.device.call('stopSpeech');
            if (recording) {
              await c.device.call('stopRecord');
              recording = false;
            } else {
              await c.device.call('record');
              recording = true;
            }
            await c.refresh();
            if (mounted) setState(() {});
          }),
        ),
        button('Stop playback', () => run(() => c.device.call('stopAudio'))),
      ],
    ),
    const Text(
      'Voice notes are private. Recording requires permission, stays in the foreground, and stops after five minutes. No transcription or upload.',
    ),
    const SizedBox(height: 16),
    TextField(
      decoration: const InputDecoration(
        labelText: 'Search titles and note text',
        prefixIcon: Icon(Icons.search),
      ),
      onChanged: (v) => setState(() => search = v.toLowerCase()),
    ),
    FilterChip(
      label: const Text('Only voice notes'),
      selected: categoryFilter == 'audio',
      onSelected: (v) => setState(() => categoryFilter = v ? 'audio' : null),
    ),
    ...c.ideas
        .where(
          (n) =>
              '${n['title']} ${n['text']}'.toLowerCase().contains(search) &&
              (categoryFilter != 'audio' || n['recording'] != null),
        )
        .map((raw) {
          final n = Map<String, dynamic>.from(raw);
          return Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    n['title'] ?? 'Idea',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  Text(n['text'] ?? ''),
                  if (n['activity'] != null) Text('Activity: ${n['activity']}'),
                  const SizedBox(height: 12),
                  Wrap(
                    children: [
                      button('Edit / rename', () => editIdea(n)),
                      button(
                        'Share selected text',
                        () => sharePreview(shareIdea(n)),
                      ),
                      button(
                        'Save text to file',
                        () => run(
                          () => c.device.call('saveText', {'text': n['text']}),
                        ),
                      ),
                      if (n['recording'] != null) ...[
                        button(
                          'Share this recording…',
                          () =>
                              sharePreview(shareIdea(n), audio: n['recording']),
                        ),
                        button(
                          'Play recording',
                          () => run(
                            () =>
                                c.device.call('play', {'name': n['recording']}),
                          ),
                        ),
                        button(
                          'Save audio to file',
                          () => run(
                            () => c.device.call('saveAudio', {
                              'name': n['recording'],
                            }),
                          ),
                        ),
                      ],
                      button(
                        'Delete',
                        () => run(() async {
                          if (await confirm(
                            'Delete this idea?',
                            'Its text and recording will be removed.',
                          ))
                            await c.deleteIdea(n['id']);
                        }),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        }),
  ];
  List<Widget> achievements() => [
    Text(
      'Participation, at your pace.',
      style: Theme.of(context).textTheme.headlineMedium,
    ),
    const SizedBox(height: 12),
    const Text(
      'These are self-reported participation milestones. Quiet breaks count equally. Sharing never earns rewards.',
    ),
    if (c.settings['gamification'] == false)
      const Padding(
        padding: EdgeInsets.all(16),
        child: Text(
          'Gamification is off. Core break history remains available.',
        ),
      )
    else
      ...badges(c.history).values.map(
        (b) => Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(b['title'], style: Theme.of(context).textTheme.titleLarge),
                Text(
                  '${b['count']} of ${b['target']}${b['earned'] != null ? ' • Earned ${b['earned']}' : ''}',
                ),
                if (b['earned'] != null)
                  button(
                    'Share this milestone',
                    () => sharePreview(shareBadge(b)),
                  ),
              ],
            ),
          ),
        ),
      ),
  ];
  Widget toggle(String title, String key, bool initial) => SwitchListTile(
    title: Text(title),
    value: c.settings[key] ?? initial,
    onChanged: (v) => c.updateSettings({key: v}),
  );
  Future<void> number(
    String key,
    String label,
    int value,
    int min,
    int max,
  ) async {
    final input = TextEditingController(text: '$value');
    final result = await showDialog<int>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(label),
        content: TextField(
          controller: input,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(
            helperText: '$min–$max',
            labelText: label,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              final n = int.tryParse(input.text);
              if (n != null && n >= min && n <= max) Navigator.pop(ctx, n);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
    if (result != null) await c.updateSettings({key: result});
  }

  List<Widget> settings() => [
    section('Timing', [
      button(
        'Work: ${c.workSeconds ~/ 60} minutes',
        () => number(
          'workSeconds',
          'Work interval in seconds',
          c.workSeconds,
          60,
          14400,
        ),
      ),
      button(
        'Break: ${c.breakSeconds} seconds',
        () => number(
          'breakSeconds',
          'Break duration in seconds',
          c.breakSeconds,
          20,
          300,
        ),
      ),
      const Text(
        'Timing changes apply to the next session. Pause automatically resumes after 15 minutes.',
      ),
      toggle('Limit reminders to active hours', 'activeEnabled', false),
      Wrap(
        children: [
          button(
            'Active from ${c.settings['activeStart'] ?? 9}:00',
            () => number(
              'activeStart',
              'Start hour',
              c.settings['activeStart'] ?? 9,
              0,
              23,
            ),
          ),
          button(
            'Active until ${c.settings['activeEnd'] ?? 18}:00',
            () => number(
              'activeEnd',
              'End hour',
              c.settings['activeEnd'] ?? 18,
              0,
              23,
            ),
          ),
        ],
      ),
      toggle('Quiet hours', 'quietHours', false),
      Wrap(
        children: [
          button(
            'Quiet from ${c.settings['quietStart'] ?? 22}:00',
            () => number(
              'quietStart',
              'Quiet start hour',
              c.settings['quietStart'] ?? 22,
              0,
              23,
            ),
          ),
          button(
            'Quiet until ${c.settings['quietEnd'] ?? 7}:00',
            () => number(
              'quietEnd',
              'Quiet end hour',
              c.settings['quietEnd'] ?? 7,
              0,
              23,
            ),
          ),
        ],
      ),
      const Text(
        'Hours use local time. Equal start and end means all day. A reminder outside allowed hours is discarded; start another work session when ready.',
      ),
      button(
        'Enable notifications',
        () => run(() => c.device.call('notifications')),
      ),
    ]),
    button('Import private activity pack', () => run(c.importPack)),
    section(
      'Activities',
      categories
          .map(
            (cat) => CheckboxListTile(
              title: Text(cat),
              value: ((c.settings['categories'] ?? categories) as List)
                  .contains(cat),
              onChanged: (v) {
                final enabled = List<String>.from(
                  c.settings['categories'] ?? categories,
                );
                v == true ? enabled.add(cat) : enabled.remove(cat);
                c.updateSettings({'categories': enabled});
              },
            ),
          )
          .toList(),
    ),
    section('Audio and accessibility', [
      toggle('Quiet mode (no activity narration)', 'quiet', true),
      toggle('Start cue sound and haptic', 'cues', false),
      button(
        'Find installed offline voices',
        () => run(() async {
          final result = await c.device.call<List>('voices');
          voices = (result ?? [])
              .map((v) => Map<String, dynamic>.from(v))
              .toList();
          setState(() {});
          if (voices.isEmpty)
            message(
              'No offline voices found. Install a local voice or use quiet mode.',
            );
        }),
      ),
      ...voices.map(
        (v) => RadioListTile<String>(
          title: Text('${v['language']} • ${v['name']}'),
          value: v['name'],
          groupValue: c.settings['voice'],
          onChanged: (v) => c.updateSettings({'voice': v}),
        ),
      ),
      button(
        'Open speech voice installer',
        () => run(() => c.device.call('installVoice')),
      ),
      const Text(
        'Only installed voices marked offline are used. Installing voice data may need a download from the speech engine. No automatic network fallback.',
      ),
      Text('Speaking rate: ${c.settings['rate'] ?? 1.0}'),
      Slider(
        value: ((c.settings['rate'] ?? 1.0) as num).toDouble(),
        min: 0.5,
        max: 1.5,
        divisions: 10,
        label: 'Speaking rate',
        onChanged: (v) => c.updateSettings({'rate': v}),
      ),
      Text('Narration volume: ${c.settings['volume'] ?? 0.8}'),
      Slider(
        value: ((c.settings['volume'] ?? 0.8) as num).toDouble(),
        min: 0,
        max: 1,
        divisions: 10,
        label: 'Narration volume',
        onChanged: (v) => c.updateSettings({'volume': v}),
      ),
      button(
        'Accessibility walkthrough',
        () => showDialog(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Use AppBreak your way'),
            content: const SingleChildScrollView(
              child: Text(
                'Quiet rest needs no screen interaction. Narration is opt-in. With TalkBack active, use its reading controls; app narration is disabled to avoid overlap. System text scaling is supported. Buttons are labelled and keyboard-focusable. Timers are not announced every second; use Read remaining time. There are no animated celebrations. You may always cancel or leave a break. Recording stops if you leave or lock the app.',
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Done'),
              ),
            ],
          ),
        ),
      ),
    ]),
    section('Progress', [
      toggle('Show optional gamification', 'gamification', true),
      button(
        'Daily goal: ${c.settings['goal'] ?? 3}',
        () =>
            number('goal', 'Daily break goal', c.settings['goal'] ?? 3, 1, 30),
      ),
    ]),
    section('Data & backup', [
      const Text(
        'No accounts, analytics, or automatic uploads. The system file picker can include cloud providers: choose your destination carefully. Backups are unencrypted; keep them private.',
      ),
      button(
        'Check storage usage',
        () => run(
          () async =>
              'App-private data: ${((await c.device.call<int>('usage') ?? 0) / 1024).ceil()} KiB',
        ),
      ),
      CheckboxListTile(
        title: const Text('Include recordings in manual backup'),
        value: includeAudio,
        onChanged: (v) => setState(() => includeAudio = v ?? false),
      ),
      button(
        'Save backup to chosen file',
        () => run(() => c.device.call('backup', {'audio': includeAudio})),
      ),
      button(
        'Choose backup to restore',
        () => run(() async {
          final p = await c.device.call<Map>('previewRestore');
          if (p != null &&
              await confirm(
                'Replace local data?',
                'Selected provider: ${p['provider']} (may be cloud-backed). Backup has ${p['ideas']} ideas and ${p['sessions']} sessions. This replaces current data; running sessions are cancelled.',
              )) {
            await c.device.call('restore');
            await c.refresh();
          }
        }),
      ),
      button(
        'Delete session history',
        () => run(() async {
          if (await confirm(
            'Delete session history?',
            'Milestones will be recalculated from the remaining history.',
          ))
            await c.act(() async {
              c.data['history'] = [];
            });
        }),
      ),
      button(
        'Delete all personal data',
        () => run(() async {
          if (await confirm(
            'Delete everything?',
            'Settings, history, ideas and recordings will be removed. Export a backup first if needed.',
          )) {
            await c.device.call('deleteAll');
            await c.refresh();
          }
        }),
      ),
    ]),
  ];
}
