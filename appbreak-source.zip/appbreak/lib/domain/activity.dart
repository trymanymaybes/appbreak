class Activity {
  final Map<String, dynamic> data;
  Activity(this.data) {
    if (data['schemaVersion'] != 1 ||
        !RegExp(r'^[a-z0-9._-]{1,80}$').hasMatch(id) ||
        seconds < 20 ||
        seconds > 300 ||
        steps.isEmpty) {
      throw FormatException('Invalid activity');
    }
  }
  String get id => data['id'];
  String get title => data['title'];
  String get category => data['category'];
  int get seconds => data['estimatedSeconds'];
  List<Map<String, dynamic>> get steps =>
      (data['steps'] as List).cast<Map<String, dynamic>>();
  String get text =>
      steps.map((s) => s['text'] ?? '').where((s) => s != '').join('\n\n');
}

const categories = [
  'quiet',
  'movement',
  'breathing',
  'hydration',
  'quiz',
  'imagination',
];
Activity chooseActivity(
  List<Activity> all,
  Set<String> enabled,
  int seconds,
  String? last,
) {
  final fit = all
      .where((a) => enabled.contains(a.category) && a.seconds <= seconds)
      .toList();
  final fresh = fit.where((a) => a.id != last).toList();
  if (fresh.isNotEmpty) return fresh.first;
  if (fit.isNotEmpty) return fit.first;
  return all.firstWhere((a) => a.id == 'quiet.soft');
}
