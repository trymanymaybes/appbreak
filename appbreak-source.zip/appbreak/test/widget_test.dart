import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:appbreak/ui/home.dart';
import 'package:appbreak/application/controller.dart';
import 'controller_test.dart' show FakeDevice;

void main() {
  testWidgets('dashboard remains usable at large text size', (tester) async {
    tester.view.physicalSize = const Size(1080, 1920);
    tester.view.devicePixelRatio = 3;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final c = Companion(FakeDevice());
    await tester.pumpWidget(
      MaterialApp(
        home: MediaQuery(
          data: const MediaQueryData(textScaler: TextScaler.linear(2)),
          child: Home(controller: c),
        ),
      ),
    );
    await tester.pump(const Duration(seconds: 1));
    expect(find.text('Start work session'), findsOneWidget);
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox());
  });
}
